package com.example.demo.controller;

import com.example.demo.model.Pessoa;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")

public class PessoaController {
    
    @PostMapping("/pessoa")
    public String cadastrarPessoa(@RequestBody Pessoa pessoa) {
        return "Pessoa cadastrada: " + pessoa.nome + " - Idade: " + pessoa.idade;

    }

}
