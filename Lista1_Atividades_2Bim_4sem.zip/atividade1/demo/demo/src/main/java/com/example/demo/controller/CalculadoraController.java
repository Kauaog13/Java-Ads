package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class CalculadoraController {

    // SOMA

    /*
     * @GetMapping("/somar")
     * public String somar(@RequestParam int num1, @RequestParam int num2) {
     * int resultado = num1 + num2;
     * return "A soma é: " + resultado;
     * }
     */

    @GetMapping("/somar/{num1}/{num2}")
    public String somar(@PathVariable int num1, @PathVariable int num2) {
        int resultado = num1 + num2;
        return "A soma é: " + resultado;
    }

    // SUBTRAÇÃO

    /*
     * @GetMapping("/subtrair")
     * public String subtrair(@RequestParam int num1, @RequestParam int num2) {
     * int resultado = num1 - num2;
     * return "A subtração é: " + resultado;
     * }
     */

    @GetMapping("/subtrair/{num1}/{num2}")
    public String subtrair(@PathVariable int num1, @PathVariable int num2) {
        int resultado = num1 - num2;
        return "A subtração é: " + resultado;
    }

    // MULTIPLICAÇÃO

    /*
     * @GetMapping("/multiplicar")
     * public String multiplicar(@RequestParam int num1, @RequestParam int num2) {
     * int resultado = num1 * num2;
     * return "A multiplicação é: " + resultado;
     * }
     */

    @GetMapping("/multiplicar/{num1}/{num2}")
    public String multiplicar(@PathVariable int num1, @PathVariable int num2) {
        int resultado = num1 * num2;
        return "A multiplicação é: " + resultado;
    }

    // DIVISÃO

    /*
     * @GetMapping("/dividir")
     * public String dividir(@RequestParam int num1, @RequestParam int num2) {
     * if (num2 == 0) {
     * return "Erro: não é possível dividir por zero!";
     * }
     * int resultado = num1 / num2;
     * return "A divisão é: " + resultado;
     * }
     */

    @GetMapping("/dividir/{num1}/{num2}")
    public String dividir(@PathVariable int num1, @PathVariable int num2) {
        if (num2 == 0) {
            return "Erro: não é possível dividir por zero!";
        }
        double resultado = num1 / num2;

        return "A divisão é: " + resultado;
    }

}