package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class HelloController {
    // Endpoint 1 - resposta simples
    @GetMapping("/hello")
    public String hello() {
        return "Olá";
    }

    // Endpoint 2 - responde com o nome informado na URL (usando @PathVariable)
    @GetMapping("/hello/{nome}")
    public String helloComNome(@PathVariable String nome) {
        return "Olá " + nome;
    }

    // Endpoint 3 - responde com o nome informado como parâmetro (usando
    // @RequestParam)
    @GetMapping("/helloComNome")
    public String helloComNomeParametro(@RequestParam String nome) {
        return "Olá, " + nome + "! Seja bem-vindo(a) ao Spring Boot!";
    }
}