import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SistemaAeronave extends JFrame {
    // Componentes da Interface [cite: 24-31]
    private JButton btnAutorizacao, btnSubir, btnPousar, btnDescer, btnResultado, btnReset;
    private JCheckBox chkChecklistOk;
    private JTextArea txtResultado;

    // Controle de Estados [cite: 50, 51]
    private boolean autorizado = false;
    private boolean subiu = false;
    private boolean pousou = false;

    public SistemaAeronave() {
        // Configurações da Janela
        setTitle("Simulador de Aeronave");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Painel Lateral (Botões)
        JPanel painelBotoes = new JPanel();
        painelBotoes.setLayout(new GridLayout(7, 1, 5, 5));

        btnAutorizacao = new JButton("Pedir Autorização");
        btnSubir = new JButton("Subir");
        btnPousar = new JButton("Pousar");
        btnDescer = new JButton("Descer");
        btnResultado = new JButton("Mostra Resultado");
        btnReset = new JButton("Reset");
        chkChecklistOk = new JCheckBox("CheckList OK");

        painelBotoes.add(btnAutorizacao);
        painelBotoes.add(btnSubir);
        painelBotoes.add(btnPousar);
        painelBotoes.add(btnDescer);
        painelBotoes.add(btnResultado);
        painelBotoes.add(btnReset);
        painelBotoes.add(chkChecklistOk);

        // Área de Texto (Status) 
        txtResultado = new JTextArea();
        txtResultado.setEditable(false);
        JScrollPane scroll = new JScrollPane(txtResultado);

        add(painelBotoes, BorderLayout.WEST);
        add(scroll, BorderLayout.CENTER);

        // --- Lógica das Funcionalidades ---

        // Pedir Autorização [cite: 10, 36, 38]
        btnAutorizacao.addActionListener(e -> {
            autorizado = true;
            txtResultado.append("Autorização concedida.\n");
        });

        // Subir [cite: 11, 18, 42-48]
        btnSubir.addActionListener(e -> {
            if (autorizado && chkChecklistOk.isSelected()) {
                subiu = true;
                txtResultado.append("Aeronave subiu.\n");
            } else if (!autorizado) {
                txtResultado.append("Aeronave não pode subir. Falta autorização.\n");
            } else {
                txtResultado.append("Checklist pendente.\n");
            }
        });

        // Pousar [cite: 12, 19]
        btnPousar.addActionListener(e -> {
            if (subiu) {
                pousou = true;
                txtResultado.append("Aeronave pousou.\n");
            } else {
                txtResultado.append("Não pode pousar sem antes subir.\n");
            }
        });

        // Descer [cite: 13, 20]
        btnDescer.addActionListener(e -> {
            if (pousou) {
                txtResultado.append("Aeronave desceu e encerrou a operação.\n");
            } else {
                txtResultado.append("Não pode descer sem antes pousar.\n");
            }
        });

        // Mostrar Resultado [cite: 15, 29]
        btnResultado.addActionListener(e -> {
            String status = String.format("Status Atual: Autorizado: %b | Subiu: %b | Pousou: %b\n", 
                                            autorizado, subiu, pousou);
            txtResultado.append(status);
        });

        // Reset [cite: 30]
        btnReset.addActionListener(e -> {
            autorizado = false;
            subiu = false;
            pousou = false;
            chkChecklistOk.setSelected(false);
            txtResultado.setText("");
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new SistemaAeronave().setVisible(true);
        });
    }
}